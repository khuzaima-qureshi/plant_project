document.addEventListener("DOMContentLoaded", function () {
    var navPlaceholder = document.getElementById("nav-placeholder");

    fetch("navbar.html")
        .then(response => response.text())
        .then(data => {
            navPlaceholder.innerHTML = data;
        })
        .catch(error => {
            console.error("Error loading navbar:", error);
        });
        var c = document.getElementById("c");
        fetch("index.html")
        .then(response => response.text())
        .then(data => {
            c.innerHTML = data;
        })
        .catch(error => {
            console.error("Error loading navbar:", error);
        });
        
});
